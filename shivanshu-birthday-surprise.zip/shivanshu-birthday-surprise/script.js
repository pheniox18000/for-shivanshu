const screens = [...document.querySelectorAll(".screen")];
const toast = document.getElementById("toast");
let toastTimer;
function showScreen(id) {
  screens.forEach(screen => {
    const active = screen.id === id;
    screen.hidden = !active;
    screen.classList.toggle("active", active);
  });
  window.scrollTo({ top: 0, behavior: "smooth" });
}
function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2400);
}
document.getElementById("open-note").addEventListener("click", () => showScreen("screen-letter"));
document.getElementById("back-home").addEventListener("click", () => showScreen("screen-welcome"));
document.getElementById("to-wishes").addEventListener("click", () => showScreen("screen-wishes"));
document.getElementById("back-letter").addEventListener("click", () => showScreen("screen-letter"));
document.getElementById("celebrate").addEventListener("click", () => {
  showScreen("screen-final");
  burstConfetti();
});
document.getElementById("restart").addEventListener("click", () => showScreen("screen-welcome"));

function burstConfetti() {
  const bits = ["✦", "♡", "✧", "🌸", "💗", "✨"];
  for (let i = 0; i < 34; i++) {
    const piece = document.createElement("span");
    piece.className = "confetti";
    piece.textContent = bits[Math.floor(Math.random() * bits.length)];
    piece.style.left = Math.random() * 100 + "vw";
    piece.style.setProperty("--drift", (Math.random() * 180 - 90) + "px");
    piece.style.animationDuration = (2.4 + Math.random() * 2.2) + "s";
    piece.style.fontSize = (12 + Math.random() * 16) + "px";
    document.body.appendChild(piece);
    setTimeout(() => piece.remove(), 5000);
  }
}

// A tiny original chime melody generated in-browser. No external audio files needed.
let audioContext = null;
let musicOn = false;
let melodyTimer = null;
let noteIndex = 0;
const notes = [523.25, 659.25, 783.99, 659.25, 587.33, 698.46, 783.99, 698.46];
function playNote(freq, startTime) {
  const osc = audioContext.createOscillator();
  const gain = audioContext.createGain();
  osc.type = "sine";
  osc.frequency.value = freq;
  gain.gain.setValueAtTime(0.0001, startTime);
  gain.gain.exponentialRampToValueAtTime(0.07, startTime + 0.035);
  gain.gain.exponentialRampToValueAtTime(0.0001, startTime + 0.42);
  osc.connect(gain);
  gain.connect(audioContext.destination);
  osc.start(startTime);
  osc.stop(startTime + 0.45);
}
function startMusic() {
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  if (!AudioCtx) {
    showToast("Music isn't supported in this browser — the surprise still works! 🤍");
    return;
  }
  if (!audioContext) audioContext = new AudioCtx();
  audioContext.resume();
  musicOn = true;
  document.getElementById("music-toggle").textContent = "♫ Pause music";
  document.getElementById("music-toggle").setAttribute("aria-pressed", "true");
  playLoop();
  melodyTimer = setInterval(playLoop, 1900);
}
function playLoop() {
  if (!musicOn || !audioContext) return;
  const now = audioContext.currentTime;
  for (let i = 0; i < 4; i++) {
    playNote(notes[noteIndex % notes.length], now + i * 0.43);
    noteIndex++;
  }
}
function stopMusic() {
  musicOn = false;
  clearInterval(melodyTimer);
  document.getElementById("music-toggle").textContent = "♫ Play music";
  document.getElementById("music-toggle").setAttribute("aria-pressed", "false");
}
document.getElementById("music-toggle").addEventListener("click", () => {
  if (musicOn) stopMusic();
  else startMusic();
});
